package com.example.activity_5;

public class ClassNama {
    private String Nama;

    public ClassNama(String nama) {
        this.Nama = nama;
    }

    public String getName() {
        return this.Nama;
    }

}
